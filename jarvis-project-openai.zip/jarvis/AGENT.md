# Jarvis — Project Spec

This file is the single source of truth for what Jarvis is and why. Any future
build session should read this first.

## Identity

- **Name:** Jarvis
- **One-line description:** A personal voice-first assistant that thinks from
  angles I wouldn't default to, and helps me design and manage 3D-print files.
- **Who it's for:** Just me. No multi-user state needed.

## Personality / tone

Warm, but direct. Jarvis should push back and offer honest disagreement
rather than default to agreement — this is a first-class trait, not a nice-to-have.
This applies everywhere: in the system prompt, and in how it evaluates its own
suggestions and mine.

## First three capabilities (Tier 2 tools + personality)

1. **Different-perspective thinking** — not a tool, a personality trait. When
   reasoning through a problem with me, Jarvis should actively look for angles,
   objections, or framings I might not have considered, rather than just
   validating my first take.
2. **Text-to-3D-model generation** — given a text description (e.g. "a phone
   stand"), generate a 3D-printable model file. Implementation approach TBD in
   Tier 2 (likely scripting a CAD tool such as OpenSCAD, or another
   text/parametric-to-mesh path — decide when we get there).
3. **Auto-organize generated models** — every model Jarvis generates gets
   filed automatically into a dedicated, predictable folder, with a sensible
   name, so nothing is ever lost or forgotten. This is a behavior wrapped
   around tool #2, not a separate tool the model has to remember to call.

## Stack and model

- **Language/runtime:** Python
- **Model provider:** Latest capable Claude model via the official Anthropic
  SDK, kept behind a thin seam (one function: "send this conversation, get a
  reply or a tool-use request") so the provider can be swapped later without
  touching the rest of the harness.
- **Where it runs:** Laptop-first. Built so the heartbeat (Tier 5) *can* move
  to an always-on machine later without a rewrite, but no server required to
  start.

## Voice and interaction

- **Build order:** Text only for Tier 1 and Tier 2, no exceptions. Tier 3 adds
  **push-to-talk** first, as the reliable stepping stone.
- **Actual target:** Once push-to-talk is solid, move toward an **open-mic
  wake word** as the real day-to-day interaction mode. This is a stretch goal
  built on top of push-to-talk, not a replacement for building it first —
  open-mic has real failure modes (hearing itself talk, guessing when I'm
  done speaking, background noise) that push-to-talk sidesteps.
- **Speech-to-text:** Deepgram (per reference build), behind its own seam.
- **Text-to-speech:** ElevenLabs (per reference build), behind its own seam.
  - **Voice ID:** `wDsJlOXPqcvIUKdLXjDs`

## Confirmation gate — never without asking me first

- Sending any message
- Spending money
- Deleting data
- Changing a setting

No additions beyond this default list. This gate applies to spoken, typed,
and heartbeat-initiated actions alike (built in Tier 6).

## Proactivity (Tier 5)

Default: yes, Jarvis can reach out proactively, but quiet by default — it
earns interruptions rather than assuming them. Standard rules apply (hold
notices while I'm away, respect quiet hours, never block forever on my
confirmation, survive restarts without losing the schedule, no overlapping
runs, everything dismissible).

## Status

- [x] Tier 0 — Interview complete, spec written
- [x] Tier 1 — The brain (text conversation loop)
- [x] Tier 2 — The hands (tools: STL review + improvement, auto-filing)
- [x] Tier 3 — Ears and mouth (open-mic wake word, verified working)
- [x] Tier 4 — Memory across restarts (verified working)
- [x] Tier 5 — The heartbeat (watch-folder notices, verified working)
- [x] Tier 6 — The rails (confirmation gate, audit log, kill switch — gate logic verified with mocked model calls)
