"""
Text interface (Tier 1/2 loop, still the primary debugging path).

This file's only job now is I/O: read typed input, hand it to the shared
agent core, print what comes back. All the actual agent logic - calling
the model, running tools - lives in jarvis/agent.py so the text and
voice interfaces never fork it.

Run it with:
    python -m jarvis.main
"""

from __future__ import annotations

import sys

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    pass

from jarvis.agent import run_agent_turn
from jarvis.brain import BrainError
from jarvis import memory_store
from jarvis.heartbeat import state as hb_state

ASSISTANT_NAME = "Jarvis"


def _print_chunk(chunk: str) -> None:
    print(chunk, end="", flush=True)


def _print_tool_start(name: str, tool_input: dict) -> None:
    print(f"\n  [running tool: {name}({tool_input})]")


def _print_tool_result(name: str, result_text: str, is_error: bool) -> None:
    preview = result_text if len(result_text) < 200 else result_text[:200] + "..."
    print(f"  [{name} -> {preview}]")


def _confirm(prompt: str) -> bool:
    print(f"\n[{ASSISTANT_NAME} needs your confirmation]")
    print(f"  {prompt}")
    answer = input("  Proceed? [y/N] ").strip().lower()
    return answer in {"y", "yes"}


def _show_pending_notices() -> None:
    """
    Whatever the heartbeat noticed while this interface was closed gets
    shown now, then cleared - held for your return, never dropped, and
    never left to pile up once you've actually seen it.
    """
    state = hb_state.load_state()
    pending = hb_state.get_pending_notices(state)
    if not pending:
        return
    print("While you were away:")
    for notice in pending:
        print(f"  - {notice['message']}")
    print()
    hb_state.dismiss_all_pending(state)
    hb_state.save_state(state)


def run() -> None:
    fact_count = len(memory_store.load_facts())
    if fact_count:
        print(f"{ASSISTANT_NAME} is up. Remembering {fact_count} thing(s) about you.")
    else:
        print(f"{ASSISTANT_NAME} is up. Type a message, or 'exit' / Ctrl-D to quit.")
    print()
    _show_pending_notices()

    conversation: list[dict] = []

    while True:
        try:
            user_input = input("you> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break

        if not user_input:
            continue
        if user_input.lower() in {"exit", "quit"}:
            print("Goodbye.")
            break

        conversation.append({"role": "user", "content": user_input})

        print(f"{ASSISTANT_NAME}> ", end="", flush=True)
        try:
            run_agent_turn(
                conversation,
                on_text=_print_chunk,
                on_tool_start=_print_tool_start,
                on_tool_result=_print_tool_result,
                on_confirm=_confirm,
            )
            print()
        except BrainError as exc:
            print(f"\n[{ASSISTANT_NAME} couldn't respond: {exc}]")
            conversation.pop()
            continue


if __name__ == "__main__":
    sys.exit(run() or 0)
