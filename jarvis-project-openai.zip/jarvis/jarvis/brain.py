"""
The provider seam - OpenAI variant.

This is the ONLY module in Jarvis that imports the OpenAI SDK directly.
Everything else (agent.py, the tools, memory, voice, heartbeat) calls
run_turn() and only ever sees a NormalizedMessage - the exact same
shape brain.py always returned when it talked to Anthropic. That's the
whole point of the seam: swapping providers means rewriting this one
file, and nothing else in the project changes.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from collections.abc import Callable

from openai import OpenAI, APIConnectionError, RateLimitError, APIStatusError, APIError

MODEL_NAME = "gpt-4o"
MAX_TOKENS = 2048


class BrainError(Exception):
    """Raised when the model can't be reached or fails in a way the
    conversation loop should show to the user instead of crashing on."""


def _get_client() -> OpenAI:
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise BrainError(
            "No OPENAI_API_KEY found. Copy .env.example to .env and add "
            "your key, or export OPENAI_API_KEY in your shell."
        )
    return OpenAI(api_key=api_key)


# --- Normalized message shape -----------------------------------------
# agent.py was written against these shapes (originally Anthropic's own
# SDK types). Reproducing the same shape here means agent.py needs zero
# changes to work with a different provider.

@dataclass
class ToolUseBlock:
    id: str = ""
    name: str = ""
    input: dict = field(default_factory=dict)
    type: str = "tool_use"


@dataclass
class TextBlock:
    text: str = ""
    type: str = "text"


@dataclass
class Usage:
    input_tokens: int
    output_tokens: int


@dataclass
class NormalizedMessage:
    content: list
    stop_reason: str  # "tool_use" or "end_turn"
    usage: Usage | None = None


def _to_openai_tools(tools: list[dict]) -> list[dict]:
    """Translate the registry's generic tool list into OpenAI's function-calling shape."""
    return [
        {
            "type": "function",
            "function": {
                "name": t["name"],
                "description": t["description"],
                "parameters": t["input_schema"],
            },
        }
        for t in tools
    ]


def _block_get(block, key, default=None):
    """Read an attribute from either a dataclass block or a dict block -
    the conversation list holds both, depending on which turn produced
    them (see agent.py)."""
    value = getattr(block, key, None)
    if value is not None:
        return value
    if isinstance(block, dict):
        return block.get(key, default)
    return default


def _to_openai_messages(messages: list[dict], system_prompt: str) -> list[dict]:
    """Translate the shared conversation list (built around the original
    Anthropic-shaped turns) into OpenAI's chat message format."""
    openai_messages = [{"role": "system", "content": system_prompt}]

    for msg in messages:
        role = msg["role"]
        content = msg["content"]

        if isinstance(content, str):
            openai_messages.append({"role": role, "content": content})
            continue

        if role == "assistant":
            text_parts = []
            tool_calls = []
            for block in content:
                block_type = _block_get(block, "type")
                if block_type == "text":
                    text_parts.append(_block_get(block, "text", ""))
                elif block_type == "tool_use":
                    tool_calls.append(
                        {
                            "id": _block_get(block, "id"),
                            "type": "function",
                            "function": {
                                "name": _block_get(block, "name"),
                                "arguments": json.dumps(_block_get(block, "input", {})),
                            },
                        }
                    )
            entry: dict = {"role": "assistant", "content": "".join(text_parts) or None}
            if tool_calls:
                entry["tool_calls"] = tool_calls
            openai_messages.append(entry)

        elif role == "user":
            is_tool_results = content and all(
                _block_get(b, "type") == "tool_result" for b in content
            )
            if is_tool_results:
                for block in content:
                    openai_messages.append(
                        {
                            "role": "tool",
                            "tool_call_id": _block_get(block, "tool_use_id"),
                            "content": str(_block_get(block, "content", "")),
                        }
                    )
            else:
                openai_messages.append({"role": "user", "content": str(content)})

    return openai_messages


def run_turn(
    messages: list[dict],
    system_prompt: str,
    tools: list[dict] | None = None,
    on_text: Callable[[str], None] | None = None,
) -> NormalizedMessage:
    """Same contract as the Anthropic version: send the conversation,
    stream text chunks to on_text, return the full turn as a
    NormalizedMessage once done."""
    client = _get_client()
    openai_messages = _to_openai_messages(messages, system_prompt)

    kwargs: dict = dict(
        model=MODEL_NAME,
        max_completion_tokens=MAX_TOKENS,
        messages=openai_messages,
        stream=True,
        stream_options={"include_usage": True},
    )
    if tools:
        kwargs["tools"] = _to_openai_tools(tools)

    try:
        stream = client.chat.completions.create(**kwargs)

        text_parts: list[str] = []
        tool_call_acc: dict[int, dict] = {}
        usage: Usage | None = None

        for chunk in stream:
            if getattr(chunk, "usage", None):
                usage = Usage(chunk.usage.prompt_tokens, chunk.usage.completion_tokens)

            if not chunk.choices:
                continue
            delta = chunk.choices[0].delta

            if delta.content:
                text_parts.append(delta.content)
                if on_text:
                    on_text(delta.content)

            if delta.tool_calls:
                for tc in delta.tool_calls:
                    idx = tc.index
                    slot = tool_call_acc.setdefault(idx, {"id": "", "name": "", "arguments": ""})
                    if tc.id:
                        slot["id"] = tc.id
                    if tc.function and tc.function.name:
                        slot["name"] += tc.function.name
                    if tc.function and tc.function.arguments:
                        slot["arguments"] += tc.function.arguments

        content_blocks: list = []
        full_text = "".join(text_parts)
        if full_text:
            content_blocks.append(TextBlock(text=full_text))

        for idx in sorted(tool_call_acc):
            tc = tool_call_acc[idx]
            try:
                parsed_input = json.loads(tc["arguments"]) if tc["arguments"] else {}
            except json.JSONDecodeError:
                parsed_input = {}
            content_blocks.append(ToolUseBlock(id=tc["id"], name=tc["name"], input=parsed_input))

        stop_reason = "tool_use" if tool_call_acc else "end_turn"
        return NormalizedMessage(content=content_blocks, stop_reason=stop_reason, usage=usage)

    except APIConnectionError as exc:
        raise BrainError("Couldn't reach the model — check your internet connection.") from exc
    except RateLimitError as exc:
        raise BrainError("Hit a rate limit talking to the model. Wait a moment and try again.") from exc
    except APIStatusError as exc:
        raise BrainError(
            f"The model API returned an error ({exc.status_code}). Try again in a moment."
        ) from exc
    except APIError as exc:
        raise BrainError(f"Unexpected error talking to the model: {exc}") from exc
