"""
Tier 3: ears and mouth, open-mic wake word.

This file only handles the voice-specific plumbing: waking on "Jarvis",
capturing your command, speaking the reply, and allowing you to
interrupt mid-reply. The actual thinking - calling the model, running
tools - is the exact same jarvis.agent.run_agent_turn() the text
interface uses. No logic is duplicated here.

Run it with:
    python -m jarvis.voice.main_voice

KNOWN LIMITATION (being upfront about it): when you interrupt Jarvis
mid-reply, it stops talking and goes back to listening for the wake
word - you'll need to say "Jarvis" again to give your next command,
rather than it seamlessly picking up your interruption as the next
command. A fully seamless handoff is possible but adds real complexity;
this is the honest, testable version to start from.
"""

from __future__ import annotations

import sys
import threading

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    pass

from jarvis.agent import run_agent_turn
from jarvis.brain import BrainError
from jarvis import memory_store
from jarvis.config import BARGE_IN_RMS_THRESHOLD
from jarvis.heartbeat import state as hb_state
from jarvis.voice.audio_io import MicStream, PlaybackController
from jarvis.voice.ears import Ears, EarsError
from jarvis.voice.mouth import Mouth, MouthError

ASSISTANT_NAME = "Jarvis"
EXIT_PHRASES = {"exit", "quit", "stop listening", "goodbye jarvis"}


def _announce_pending_notices(mouth: Mouth) -> None:
    """
    Whatever the heartbeat noticed while you were away gets spoken now,
    then cleared - the natural voice-mode equivalent of the text
    interface's startup summary. Held for your return, never dropped.
    """
    state = hb_state.load_state()
    pending = hb_state.get_pending_notices(state)
    if not pending:
        return
    summary = "While you were away: " + " Also, ".join(n["message"] for n in pending)
    print(f"[{ASSISTANT_NAME}] {summary}")
    _speak_with_barge_in(mouth, summary)
    hb_state.dismiss_all_pending(state)
    hb_state.save_state(state)


def _barge_in_watcher(playback: PlaybackController, stop_flag: threading.Event) -> None:
    """
    Runs on its own thread while Jarvis is speaking. Uses simple local
    loudness detection (no API calls - this just needs to notice "the
    person is talking", not understand what they said) to interrupt
    playback the moment you start speaking over it.
    """
    mic = MicStream()
    mic.start()
    try:
        while not stop_flag.is_set():
            chunk = mic.read_chunk(timeout=0.1)
            if chunk is None:
                continue
            if mic.last_rms > BARGE_IN_RMS_THRESHOLD:
                playback.interrupt()
                return
    finally:
        mic.stop()


def _speak_with_barge_in(mouth: Mouth, text: str) -> bool:
    """Speaks `text`, watching for interruption. Returns True if interrupted."""
    playback = PlaybackController()
    stop_flag = threading.Event()
    watcher = threading.Thread(
        target=_barge_in_watcher, args=(playback, stop_flag), daemon=True
    )
    watcher.start()
    try:
        mouth.speak(text, playback)
    except MouthError as exc:
        print(f"[{ASSISTANT_NAME} couldn't speak: {exc}]")
    finally:
        stop_flag.set()
        watcher.join(timeout=1.0)
    return playback.should_stop


def _make_confirm(ears: Ears, mouth: Mouth):
    """
    Builds the voice-mode confirmation callback. Speaks the question,
    then listens directly for the answer - no wake word needed, since
    Jarvis just asked a direct question and waiting for "Jarvis, yes"
    would be strange. If nothing is heard within the timeout, that's
    treated as a decline, never as "keep waiting" - per the same
    never-block-forever rule the heartbeat follows.
    """

    def _confirm(prompt: str) -> bool:
        print(f"\n[{ASSISTANT_NAME} needs your confirmation]: {prompt}")
        _speak_with_barge_in(mouth, prompt + " Say yes or no.")
        reply_text, heard_text = ears.listen_for_short_reply(timeout_seconds=15.0)
        print(f"[heard confirmation reply]: {heard_text!r}")
        if not reply_text:
            print("[no response in time - treating as declined]")
            return False
        lowered = reply_text.lower()
        return any(word in lowered for word in ("yes", "yeah", "yep", "confirm", "sure", "go ahead"))

    return _confirm


def run() -> None:
    try:
        ears = Ears()
        mouth = Mouth()
    except (EarsError, MouthError) as exc:
        print(f"Couldn't start voice mode: {exc}")
        return

    fact_count = len(memory_store.load_facts())
    remembered = f" Remembering {fact_count} thing(s) about you." if fact_count else ""
    print(
        f"{ASSISTANT_NAME} is listening.{remembered} Say 'Jarvis' followed by "
        f"what you want. Ctrl-C to quit.\n"
    )

    _announce_pending_notices(mouth)

    confirm = _make_confirm(ears, mouth)
    conversation: list[dict] = []

    while True:
        try:
            print("[listening for wake word...]")
            command_text, heard_text = ears.listen_for_command()
        except EarsError as exc:
            print(f"[couldn't hear you: {exc}]")
            continue
        except KeyboardInterrupt:
            print("\nGoodbye.")
            break

        # Always show what it thought it heard, per the "don't hide
        # mishearing" rule - this is how you catch the ears getting it
        # wrong versus the brain getting it wrong.
        print(f"[heard]: {heard_text!r}")

        if not command_text:
            # Wake word heard, but nothing usable followed it.
            _speak_with_barge_in(mouth, "Yes?")
            continue

        if command_text.strip().lower() in EXIT_PHRASES:
            _speak_with_barge_in(mouth, "Goodbye.")
            break

        conversation.append({"role": "user", "content": command_text})

        reply_parts: list[str] = []

        def _on_text(chunk: str) -> None:
            print(chunk, end="", flush=True)
            reply_parts.append(chunk)

        def _on_tool_start(name: str, tool_input: dict) -> None:
            print(f"\n  [running tool: {name}({tool_input})]")

        def _on_tool_result(name: str, result_text: str, is_error: bool) -> None:
            preview = result_text if len(result_text) < 200 else result_text[:200] + "..."
            print(f"  [{name} -> {preview}]")

        print(f"{ASSISTANT_NAME}> ", end="", flush=True)
        try:
            run_agent_turn(
                conversation,
                on_text=_on_text,
                on_tool_start=_on_tool_start,
                on_tool_result=_on_tool_result,
                on_confirm=confirm,
            )
            print()
        except BrainError as exc:
            print(f"\n[{ASSISTANT_NAME} couldn't respond: {exc}]")
            conversation.pop()
            _speak_with_barge_in(mouth, "Sorry, I couldn't reach my brain just now.")
            continue

        full_reply = "".join(reply_parts)
        interrupted = _speak_with_barge_in(mouth, full_reply)
        if interrupted:
            print("[interrupted - say 'Jarvis' to give your next command]")


if __name__ == "__main__":
    sys.exit(run() or 0)
