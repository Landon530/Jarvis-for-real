"""
Low-level audio in/out. Nothing here knows about Deepgram, ElevenLabs,
wake words, or the agent - it just captures raw microphone audio and
plays raw audio back. Keeping this dumb and separate makes it easy to
swap the mic/speaker library later without touching ears.py or mouth.py.
"""

from __future__ import annotations

import queue
import threading

import numpy as np
import sounddevice as sd

SAMPLE_RATE = 16000  # Deepgram's live API expects 16kHz mono by default
CHANNELS = 1
DTYPE = "int16"
BLOCK_MS = 30  # size of each captured chunk, in milliseconds
BLOCK_SIZE = int(SAMPLE_RATE * BLOCK_MS / 1000)


class MicStream:
    """
    Wraps a sounddevice InputStream and exposes captured audio as raw
    PCM16 bytes via an iterator, plus a running RMS level any caller can
    read for lightweight local voice-activity detection (used for
    barge-in - see mouth.py).
    """

    def __init__(self) -> None:
        self._q: queue.Queue[bytes] = queue.Queue()
        self._stream: sd.InputStream | None = None
        self.last_rms: float = 0.0

    def _callback(self, indata, frames, time_info, status) -> None:  # noqa: ANN001
        if status:
            # Overflows happen occasionally under load; don't crash on them.
            pass
        audio = indata.copy()
        self.last_rms = float(np.sqrt(np.mean(audio.astype(np.float32) ** 2)))
        self._q.put(audio.tobytes())

    def start(self) -> None:
        self._stream = sd.InputStream(
            samplerate=SAMPLE_RATE,
            channels=CHANNELS,
            dtype=DTYPE,
            blocksize=BLOCK_SIZE,
            callback=self._callback,
        )
        self._stream.start()

    def stop(self) -> None:
        if self._stream is not None:
            self._stream.stop()
            self._stream.close()
            self._stream = None
        # Drain any queued audio so a restart doesn't replay stale chunks.
        while not self._q.empty():
            try:
                self._q.get_nowait()
            except queue.Empty:
                break

    def read_chunk(self, timeout: float = 1.0) -> bytes | None:
        """Blocks briefly for the next captured chunk; returns None on timeout."""
        try:
            return self._q.get(timeout=timeout)
        except queue.Empty:
            return None


class PlaybackController:
    """
    Tiny shared flag so a barge-in watcher thread can tell an in-progress
    playback to stop early. mouth.py checks `should_stop` between audio
    chunks; whatever detects the interruption calls `interrupt()`.
    """

    def __init__(self) -> None:
        self._stop_event = threading.Event()

    def interrupt(self) -> None:
        self._stop_event.set()

    def reset(self) -> None:
        self._stop_event.clear()

    @property
    def should_stop(self) -> bool:
        return self._stop_event.is_set()
