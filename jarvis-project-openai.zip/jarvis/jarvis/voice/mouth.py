"""
The mouth: speaks text aloud via ElevenLabs, streaming so playback can
start before the whole reply is synthesized. Behind the same seam
discipline - this is the only module that talks to ElevenLabs directly.

Supports being interrupted mid-sentence (barge-in): the caller passes a
PlaybackController, and a separate watcher thread (run by
voice/main_voice.py, using local RMS-based voice-activity detection on
the mic - no need to hit Deepgram just to notice "someone started
talking") can call `interrupt()` on it to stop playback immediately.

NOTE: written against the documented `elevenlabs` Python SDK. Like
ears.py, if the installed SDK's exact method names differ, only this
file needs adjusting.
"""

from __future__ import annotations

import os

import numpy as np
import sounddevice as sd
from elevenlabs.client import ElevenLabs

from jarvis.config import ELEVENLABS_VOICE_ID
from jarvis.voice.audio_io import PlaybackController


class MouthError(Exception):
    """Raised when speech can't be synthesized or played."""


class Mouth:
    def __init__(self) -> None:
        api_key = os.environ.get("ELEVENLABS_API_KEY")
        if not api_key:
            raise MouthError(
                "No ELEVENLABS_API_KEY found. Add it to .env — needed for "
                "Jarvis to speak."
            )
        self._client = ElevenLabs(api_key=api_key)

    def speak(self, text: str, playback: PlaybackController) -> None:
        """
        Synthesize and play `text` aloud, streaming as it's generated.
        Stops early (mid-sentence) if `playback.should_stop` becomes
        true while playing - that's how a barge-in interrupt takes
        effect immediately rather than after the sentence finishes.
        """
        if not text.strip():
            return

        try:
            audio_stream = self._client.text_to_speech.convert_as_stream(
                voice_id=ELEVENLABS_VOICE_ID,
                model_id="eleven_turbo_v2_5",
                text=text,
                output_format="pcm_16000",
            )
        except Exception as exc:  # noqa: BLE001
            raise MouthError(f"Couldn't synthesize speech: {exc}") from exc

        try:
            with sd.OutputStream(samplerate=16000, channels=1, dtype="int16") as out:
                for chunk in audio_stream:
                    if playback.should_stop:
                        break
                    if not chunk:
                        continue
                    samples = np.frombuffer(chunk, dtype=np.int16)
                    out.write(samples)
        except Exception as exc:  # noqa: BLE001
            raise MouthError(f"Playback failed: {exc}") from exc
