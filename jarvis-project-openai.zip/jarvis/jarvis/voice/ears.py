"""
The ears: continuous open-mic listening for the wake word, then capturing
whatever's said next as a command.

Behind the same "seam" discipline as brain.py - this is the only module
that talks to Deepgram directly. If a different transcriber is swapped
in later, only this file changes.

How it works:
  1. Stream raw mic audio to Deepgram's live transcription websocket
     continuously, while idle.
  2. Watch finalized transcript segments for the wake word. Everything
     before it is discarded (it wasn't meant for Jarvis).
  3. Once heard, start accumulating transcript text as "the command",
     until Deepgram signals an UtteranceEnd (a pause) - that's the
     person finishing their sentence.
  4. Return the command text. The caller (voice/main_voice.py) then runs
     it through the exact same agent core the text interface uses.

NOTE: this is written against the documented Deepgram Python SDK v3
live-transcription API. SDK method names shift between versions more
than most libraries - if `deepgram-sdk` on your machine differs, the
error will point at this file specifically, and only this file needs
adjusting.
"""

from __future__ import annotations

import os
import threading
import time

from deepgram import (
    DeepgramClient,
    LiveOptions,
    LiveTranscriptionEvents,
)

from jarvis.config import UTTERANCE_END_MS, WAKE_WORD
from jarvis.voice.audio_io import MicStream


class EarsError(Exception):
    """Raised when speech can't be captured or transcribed."""


class Ears:
    def __init__(self) -> None:
        api_key = os.environ.get("DEEPGRAM_API_KEY")
        if not api_key:
            raise EarsError(
                "No DEEPGRAM_API_KEY found. Add it to .env — needed for "
                "Jarvis to hear you."
            )
        self._client = DeepgramClient(api_key)
        self._mic = MicStream()

    def listen_for_command(self) -> tuple[str, str]:
        """
        Blocks until the wake word is heard, then blocks further until
        the person finishes speaking their command.

        Returns (command_text, raw_heard_text) - the second value is the
        full transcript including the wake word, kept around so the
        caller can print it for debugging per the "always show what it
        thought it heard" rule.
        """
        state = {"phase": "waiting_for_wake", "command_parts": [], "heard": []}
        done = threading.Event()
        error: list[Exception] = []

        connection = self._client.listen.websocket.v("1")

        def on_transcript(self_conn, result, **kwargs) -> None:  # noqa: ANN001
            try:
                alt = result.channel.alternatives[0]
                text = alt.transcript.strip()
                if not text or not result.is_final:
                    return

                state["heard"].append(text)

                if state["phase"] == "waiting_for_wake":
                    lowered = text.lower()
                    if WAKE_WORD in lowered:
                        state["phase"] = "capturing_command"
                        # Keep anything the person said *after* the wake
                        # word in the same breath as the start of the command.
                        idx = lowered.find(WAKE_WORD)
                        remainder = text[idx + len(WAKE_WORD):].strip(" ,.:;-")
                        if remainder:
                            state["command_parts"].append(remainder)
                elif state["phase"] == "capturing_command":
                    state["command_parts"].append(text)
            except Exception as exc:  # noqa: BLE001
                error.append(exc)
                done.set()

        def on_utterance_end(self_conn, utterance_end, **kwargs) -> None:  # noqa: ANN001
            if state["phase"] == "capturing_command" and state["command_parts"]:
                done.set()

        def on_error(self_conn, err, **kwargs) -> None:  # noqa: ANN001
            error.append(EarsError(f"Deepgram error: {err}"))
            done.set()

        connection.on(LiveTranscriptionEvents.Transcript, on_transcript)
        connection.on(LiveTranscriptionEvents.UtteranceEnd, on_utterance_end)
        connection.on(LiveTranscriptionEvents.Error, on_error)

        options = LiveOptions(
            model="nova-2",
            language="en-US",
            smart_format=True,
            interim_results=True,
            utterance_end_ms=str(UTTERANCE_END_MS),
            vad_events=True,
            encoding="linear16",
            sample_rate=16000,
            channels=1,
        )

        if not connection.start(options):
            raise EarsError("Couldn't open Deepgram connection.")

        self._mic.start()
        try:
            while not done.is_set():
                chunk = self._mic.read_chunk(timeout=1.0)
                if chunk:
                    connection.send(chunk)
        finally:
            self._mic.stop()
            connection.finish()

        if error:
            raise EarsError(str(error[0]))

        command_text = " ".join(state["command_parts"]).strip()
        heard_text = " ".join(state["heard"]).strip()

        if not command_text:
            # Wake word heard but nothing usable followed - let the
            # caller decide how to handle that (e.g. ask "yes?").
            return "", heard_text

        return command_text, heard_text

    def listen_for_short_reply(self, timeout_seconds: float = 15.0) -> tuple[str, str]:
        """
        Captures the next thing said WITHOUT requiring the wake word -
        used right after Jarvis has directly asked a yes/no question, so
        making the person say "Jarvis" again first would be strange.

        Times out after `timeout_seconds` of silence with nothing heard.
        Per the Tier 5 "never block forever waiting on a human" rule,
        applied here too: a timeout returns ("", "") and the caller
        should treat that as a non-approval, not keep waiting.

        Returns (reply_text, raw_heard_text).
        """
        state = {"parts": [], "heard": []}
        done = threading.Event()
        error: list[Exception] = []

        connection = self._client.listen.websocket.v("1")

        def on_transcript(self_conn, result, **kwargs) -> None:  # noqa: ANN001
            try:
                alt = result.channel.alternatives[0]
                text = alt.transcript.strip()
                if not text or not result.is_final:
                    return
                state["heard"].append(text)
                state["parts"].append(text)
            except Exception as exc:  # noqa: BLE001
                error.append(exc)
                done.set()

        def on_utterance_end(self_conn, utterance_end, **kwargs) -> None:  # noqa: ANN001
            if state["parts"]:
                done.set()

        def on_error(self_conn, err, **kwargs) -> None:  # noqa: ANN001
            error.append(EarsError(f"Deepgram error: {err}"))
            done.set()

        connection.on(LiveTranscriptionEvents.Transcript, on_transcript)
        connection.on(LiveTranscriptionEvents.UtteranceEnd, on_utterance_end)
        connection.on(LiveTranscriptionEvents.Error, on_error)

        options = LiveOptions(
            model="nova-2",
            language="en-US",
            smart_format=True,
            interim_results=True,
            utterance_end_ms=str(UTTERANCE_END_MS),
            vad_events=True,
            encoding="linear16",
            sample_rate=16000,
            channels=1,
        )

        if not connection.start(options):
            raise EarsError("Couldn't open Deepgram connection.")

        self._mic.start()
        start_time = time.time()
        try:
            while not done.is_set():
                if time.time() - start_time > timeout_seconds:
                    break  # timed out - treated as no response, not an error
                chunk = self._mic.read_chunk(timeout=0.5)
                if chunk:
                    connection.send(chunk)
        finally:
            self._mic.stop()
            connection.finish()

        if error:
            raise EarsError(str(error[0]))

        reply_text = " ".join(state["parts"]).strip()
        heard_text = " ".join(state["heard"]).strip()
        return reply_text, heard_text
