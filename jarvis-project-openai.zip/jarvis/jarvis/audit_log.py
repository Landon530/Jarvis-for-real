"""
The audit trail: a single plain-text, append-only log of what Jarvis
did and why. Every tool call, every confirmation asked (and how it was
answered), every heartbeat notice, and per-turn token usage land here,
timestamped. When something surprises you, this file is how you find
out what happened.

Deliberately just lines of text in a file - readable with any editor,
`tail -f`-able while Jarvis runs, and never a black box.
"""

from __future__ import annotations

import datetime as _dt

from jarvis.config import AUDIT_LOG_FILE


def log(event: str) -> None:
    AUDIT_LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    timestamp = _dt.datetime.now().isoformat(timespec="seconds")
    with AUDIT_LOG_FILE.open("a", encoding="utf-8") as f:
        f.write(f"[{timestamp}] {event}\n")
