"""
Long-term memory (Tier 4): durable facts that survive a restart.

Deliberately simple: one fact per line, in a plain text file you can
open, read, and hand-edit yourself at any time. Memory you can't
inspect is memory you can't trust - so no database, no hidden blob,
just lines in a file.

This is separate from the in-session conversation history (still just
a Python list that resets when the program exits). This file is what
lets Jarvis actually know you across sessions.

Facts stored here are loaded into the system prompt as background
knowledge only - see agent.py. They are never treated as instructions
to obey, so a stored note can't quietly become a backdoor around the
Tier 6 confirmation gate.
"""

from __future__ import annotations

from pathlib import Path

from jarvis.config import MEMORY_FILE


def _ensure_file() -> Path:
    MEMORY_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not MEMORY_FILE.exists():
        MEMORY_FILE.write_text("", encoding="utf-8")
    return MEMORY_FILE


def load_facts() -> list[str]:
    """Every stored fact, in the order they were added."""
    path = _ensure_file()
    lines = path.read_text(encoding="utf-8").splitlines()
    return [line.strip() for line in lines if line.strip()]


def add_fact(fact: str) -> None:
    """Append a new fact. Silently skips exact duplicates."""
    fact = fact.strip()
    if not fact:
        return
    path = _ensure_file()
    if fact in load_facts():
        return
    with path.open("a", encoding="utf-8") as f:
        f.write(fact + "\n")


def remove_fact(fact_substring: str) -> list[str]:
    """
    Remove every stored fact containing `fact_substring`
    (case-insensitive). Returns the facts that were actually removed,
    so the caller can confirm what happened.
    """
    path = _ensure_file()
    needle = fact_substring.strip().lower()
    facts = load_facts()
    kept, removed = [], []
    for fact in facts:
        if needle and needle in fact.lower():
            removed.append(fact)
        else:
            kept.append(fact)
    path.write_text("\n".join(kept) + ("\n" if kept else ""), encoding="utf-8")
    return removed


def update_fact(old_substring: str, new_fact: str) -> bool:
    """
    Replace the first stored fact containing `old_substring` with
    `new_fact`. Returns whether a match was found.
    """
    path = _ensure_file()
    needle = old_substring.strip().lower()
    facts = load_facts()
    replaced = False
    updated: list[str] = []
    for fact in facts:
        if not replaced and needle in fact.lower():
            updated.append(new_fact.strip())
            replaced = True
        else:
            updated.append(fact)
    if replaced:
        path.write_text("\n".join(updated) + "\n", encoding="utf-8")
    return replaced
