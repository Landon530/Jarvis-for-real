"""
The heartbeat loop itself.

Wakes on a short interval, asks each registered check whether it's due
(based on persisted last-run time, not just in-memory state - so a
restart resumes the schedule instead of firing everything at once),
runs any that are due, and queues whatever notices they raise.

Because this loop is single-threaded and each check runs to completion
before the next iteration begins, a slow check can never overlap with
itself - the "don't stack overlapping runs" rule is satisfied by the
loop's own structure, not extra locking.
"""

from __future__ import annotations

import datetime as _dt
import time

from jarvis import audit_log
from jarvis.config import (
    HEARTBEAT_CHECK_INTERVAL_SECONDS,
    HEARTBEAT_LOOP_SLEEP_SECONDS,
    KILL_SWITCH_FILE,
    QUIET_HOURS_END,
    QUIET_HOURS_START,
)
from jarvis.heartbeat import kill_switch
from jarvis.heartbeat import state as hb_state
from jarvis.heartbeat.checks import CHECKS


def _parse_hhmm(value: str) -> _dt.time:
    hour, minute = value.split(":")
    return _dt.time(int(hour), int(minute))


def in_quiet_hours(now: _dt.time | None = None) -> bool:
    now = now or _dt.datetime.now().time()
    start = _parse_hhmm(QUIET_HOURS_START)
    end = _parse_hhmm(QUIET_HOURS_END)
    if start <= end:
        return start <= now <= end
    # Window wraps past midnight, e.g. 22:00 -> 08:00.
    return now >= start or now <= end


def run_due_checks(state: dict) -> list[str]:
    """
    Runs every check whose interval has elapsed, queues any notices it
    raises, and updates last-run times. Returns the plain-text notice
    messages raised this pass (empty most of the time - that's the
    point: most checks produce nothing most of the time).
    """
    now = time.time()
    raised: list[str] = []

    for name, check_fn in CHECKS.items():
        last_run = hb_state.get_last_run(state, name)
        if now - last_run < HEARTBEAT_CHECK_INTERVAL_SECONDS:
            continue

        messages = check_fn(state)
        for message in messages:
            hb_state.add_notice(state, message)
            raised.append(message)

        hb_state.set_last_run(state, name, now)

    return raised


def run_forever() -> None:
    """
    The main heartbeat loop. Runs until interrupted (Ctrl-C). Each pass:
    check the kill switch, load state, run any due checks, save state,
    sleep. Loading/saving state every pass (rather than keeping it only
    in memory) means an unexpected exit never loses a notice or resets
    the schedule.
    """
    print(
        f"Heartbeat running. Checking every "
        f"{HEARTBEAT_CHECK_INTERVAL_SECONDS}s, watching for updates every "
        f"{HEARTBEAT_LOOP_SLEEP_SECONDS}s. Ctrl-C to stop.\n"
        f"Kill switch: create {KILL_SWITCH_FILE} (or run "
        f"'python -m jarvis.heartbeat.pause') to pause without stopping "
        f"this process.\n"
    )
    was_paused = False
    while True:
        try:
            paused = kill_switch.is_paused()
            if paused and not was_paused:
                print("[heartbeat] Paused via kill switch — no checks will run until resumed.")
                audit_log.log("heartbeat_paused")
            elif not paused and was_paused:
                print("[heartbeat] Resumed — checks running again.")
                audit_log.log("heartbeat_resumed")
            was_paused = paused

            if not paused:
                state = hb_state.load_state()
                raised = run_due_checks(state)
                hb_state.save_state(state)

                for message in raised:
                    audit_log.log(f"heartbeat_notice: {message}")
                    if in_quiet_hours():
                        print(f"[heartbeat, held for quiet hours] {message}")
                    else:
                        print(f"[heartbeat] {message}")

            time.sleep(HEARTBEAT_LOOP_SLEEP_SECONDS)
        except KeyboardInterrupt:
            print("\nHeartbeat stopped.")
            break
        except Exception as exc:  # noqa: BLE001
            # A bug in a check shouldn't kill the whole background
            # process - log it and keep the loop alive.
            print(f"[heartbeat] unexpected error, continuing: {exc}")
            audit_log.log(f"heartbeat_error: {exc}")
            time.sleep(HEARTBEAT_LOOP_SLEEP_SECONDS)
