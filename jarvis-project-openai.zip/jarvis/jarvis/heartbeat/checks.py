"""
Individual heartbeat checks. Each is a small, self-contained function:
what it looks at, and how it decides something is worth surfacing.
Adding a new check later means writing one function here and
registering it in scheduler.py - nothing else changes.
"""

from __future__ import annotations

from jarvis.config import WATCH_DIR
from jarvis.heartbeat import state as hb_state


def check_new_stl_files(state: dict) -> list[str]:
    """
    Look in WATCH_DIR for .stl files that haven't been seen before.
    Read-only, safe to run unattended - it only ever queues a notice,
    never touches the file.
    """
    WATCH_DIR.mkdir(parents=True, exist_ok=True)

    new_messages = []
    for path in sorted(WATCH_DIR.glob("*.stl")):
        resolved = str(path.resolve())
        if hb_state.has_seen(state, resolved):
            continue
        hb_state.mark_seen(state, resolved)
        new_messages.append(
            f"New model in your watch folder: {path.name} — want me to take a look?"
        )
    return new_messages


# Registered in scheduler.py: name -> (check_function, interval_seconds)
CHECKS = {
    "watch_new_stl": check_new_stl_files,
}
