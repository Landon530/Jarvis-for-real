"""Run with: python -m jarvis.heartbeat.resume"""

from jarvis.heartbeat.kill_switch import resume

if __name__ == "__main__":
    resume()
    print("Heartbeat resumed.")
