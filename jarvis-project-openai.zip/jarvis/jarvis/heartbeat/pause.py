"""Run with: python -m jarvis.heartbeat.pause"""

from jarvis.config import KILL_SWITCH_FILE
from jarvis.heartbeat.kill_switch import pause

if __name__ == "__main__":
    pause()
    print(f"Heartbeat paused. (Marker file: {KILL_SWITCH_FILE})")
    print("Run 'python -m jarvis.heartbeat.resume' to resume.")
