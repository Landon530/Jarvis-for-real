"""
Tier 5 entry point: run the heartbeat as its own background process,
separate from whatever text or voice session you have open.

Run it with:
    python -m jarvis.heartbeat.main_heartbeat

Leave it running in its own terminal (or eventually, per Tier 5's design
note, move it to an always-on machine later - this loop doesn't care
which machine it's on). It only ever queues notices; it never sends
anything, spends anything, deletes anything, or changes a setting, so
it doesn't need the Tier 6 confirmation gate yet. That gate will matter
once a check does something consequential.
"""

from __future__ import annotations

import sys

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    pass

from jarvis.heartbeat.scheduler import run_forever

if __name__ == "__main__":
    sys.exit(run_forever() or 0)
