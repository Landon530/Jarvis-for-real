"""
The kill switch: one obvious way to pause all heartbeat activity
without tearing anything down. Implemented as the presence/absence of
a marker file, so it works whether you touch the file directly, script
it, or use the two convenience commands below - and so resuming is
just removing it, not restarting anything.
"""

from __future__ import annotations

from jarvis.config import KILL_SWITCH_FILE


def is_paused() -> bool:
    return KILL_SWITCH_FILE.exists()


def pause() -> None:
    KILL_SWITCH_FILE.parent.mkdir(parents=True, exist_ok=True)
    KILL_SWITCH_FILE.write_text(
        "Jarvis's heartbeat is paused.\n"
        "Delete this file, or run: python -m jarvis.heartbeat.resume\n",
        encoding="utf-8",
    )


def resume() -> None:
    if KILL_SWITCH_FILE.exists():
        KILL_SWITCH_FILE.unlink()
