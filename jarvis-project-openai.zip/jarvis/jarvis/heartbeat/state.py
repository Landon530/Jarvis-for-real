"""
Persistent heartbeat state.

Three things live here, all in one small JSON file:
  - which files a check has already seen (so restarting doesn't re-flag
    everything as new)
  - notices that have been raised but not yet shown to the person
    (so closing the app doesn't lose them - they're held for return)
  - when each check last ran (so restarting resumes the schedule
    instead of firing every check at once on boot)

Kept as one file, read-modify-write, because the heartbeat's whole job
is small and infrequent - no need for anything heavier.
"""

from __future__ import annotations

import json
import time
import uuid
from pathlib import Path

from jarvis.config import HEARTBEAT_STATE_FILE

_DEFAULT_STATE = {"seen_files": [], "notices": [], "last_run": {}}


def load_state() -> dict:
    if not HEARTBEAT_STATE_FILE.exists():
        return dict(_DEFAULT_STATE)
    try:
        with HEARTBEAT_STATE_FILE.open(encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        # A corrupted state file shouldn't crash the heartbeat - start
        # fresh rather than taking the whole loop down.
        return dict(_DEFAULT_STATE)
    for key, default in _DEFAULT_STATE.items():
        data.setdefault(key, default)
    return data


def save_state(state: dict) -> None:
    HEARTBEAT_STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with HEARTBEAT_STATE_FILE.open("w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)


def mark_seen(state: dict, path: str) -> None:
    seen = set(state.get("seen_files", []))
    seen.add(path)
    state["seen_files"] = sorted(seen)


def has_seen(state: dict, path: str) -> bool:
    return path in state.get("seen_files", [])


def add_notice(state: dict, message: str) -> dict:
    notice = {
        "id": uuid.uuid4().hex[:8],
        "message": message,
        "created": time.time(),
        "dismissed": False,
    }
    state.setdefault("notices", []).append(notice)
    return notice


def get_pending_notices(state: dict) -> list[dict]:
    return [n for n in state.get("notices", []) if not n.get("dismissed")]


def dismiss_all_pending(state: dict) -> None:
    """
    Called when the text or voice interface starts up and shows
    whatever accumulated while you were away - being shown to you IS
    the dismissal, so an inbox of old notices never piles up unread.
    """
    for notice in state.get("notices", []):
        notice["dismissed"] = True
    # Keep the list from growing forever - drop old dismissed notices,
    # they've done their job once shown.
    state["notices"] = [n for n in state.get("notices", []) if not n.get("dismissed")]


def get_last_run(state: dict, check_name: str) -> float:
    return state.get("last_run", {}).get(check_name, 0.0)


def set_last_run(state: dict, check_name: str, timestamp: float) -> None:
    state.setdefault("last_run", {})[check_name] = timestamp
