"""
Jarvis config. Values here are the ones you'll want to tune as you use
Jarvis — keep new settings here, not scattered through the tools.
"""

from __future__ import annotations

import os
from pathlib import Path

# Where every model Jarvis touches gets filed. Override by setting
# JARVIS_MODELS_DIR in your environment or .env file. Defaults to a
# folder in your home directory so it's easy to find and survives the
# project folder being moved or rebuilt.
MODELS_DIR = Path(os.environ.get("JARVIS_MODELS_DIR", str(Path.home() / "JarvisModels")))


def ensure_models_dir() -> Path:
    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    return MODELS_DIR


# --- Voice (Tier 3) ---------------------------------------------------

# The word Jarvis listens for before it starts treating speech as a
# command. Case-insensitive substring match against what Deepgram hears.
WAKE_WORD = os.environ.get("JARVIS_WAKE_WORD", "jarvis")

# ElevenLabs voice used for spoken replies.
ELEVENLABS_VOICE_ID = os.environ.get("ELEVENLABS_VOICE_ID", "wDsJlOXPqcvIUKdLXjDs")

# How long a silence (in ms) ends a spoken command / marks the model's
# reply as finished being interruptible. Tune if it cuts you off early
# or waits too long after you stop talking.
UTTERANCE_END_MS = int(os.environ.get("JARVIS_UTTERANCE_END_MS", "1200"))

# RMS loudness (0-32768 scale, int16 audio) above which the barge-in
# watcher decides "someone started talking" while Jarvis is speaking and
# interrupts playback. Background noise is usually well under 200; a
# raised speaking voice close to the mic is usually 1000+. If Jarvis
# interrupts itself on room noise, raise this; if it doesn't notice you
# trying to cut in, lower it.
BARGE_IN_RMS_THRESHOLD = int(os.environ.get("JARVIS_BARGE_IN_RMS_THRESHOLD", "600"))

# --- Memory (Tier 4) ----------------------------------------------------

# Where durable facts live: one plain statement per line, in a file you
# can open and hand-edit any time. This is long-term memory - separate
# from the in-session conversation history, which still resets on
# restart.
MEMORY_FILE = Path(os.environ.get("JARVIS_MEMORY_FILE", str(Path.home() / "JarvisMemory.md")))

# --- Heartbeat (Tier 5) --------------------------------------------------

# Drop new STL files here and Jarvis's heartbeat will notice them and
# offer to review them. Deliberately separate from MODELS_DIR (Tier 2's
# output folder) so Jarvis never flags its own generated files as new.
WATCH_DIR = Path(os.environ.get("JARVIS_WATCH_DIR", str(Path.home() / "JarvisWatch")))

# How often (seconds) the "new STL" check actually runs. The loop itself
# wakes more often than this (see HEARTBEAT_LOOP_SLEEP_SECONDS) so it can
# stay responsive to being stopped, but each check only fires this often.
HEARTBEAT_CHECK_INTERVAL_SECONDS = int(os.environ.get("JARVIS_HEARTBEAT_CHECK_INTERVAL", "60"))

# How often (seconds) the heartbeat loop wakes up to see if any check is
# due. Should be <= the smallest check interval.
HEARTBEAT_LOOP_SLEEP_SECONDS = int(os.environ.get("JARVIS_HEARTBEAT_LOOP_SLEEP", "15"))

# Non-urgent notices are held quietly during this window (24h "HH:MM",
# can wrap past midnight). Nothing is lost - they're just not printed
# prominently until you're back.
QUIET_HOURS_START = os.environ.get("JARVIS_QUIET_HOURS_START", "22:00")
QUIET_HOURS_END = os.environ.get("JARVIS_QUIET_HOURS_END", "08:00")

# Persistent heartbeat state: which files have already been seen, which
# notices are still pending, and when each check last ran - so a
# restart resumes the schedule instead of refiring everything at once.
HEARTBEAT_STATE_FILE = Path(
    os.environ.get("JARVIS_HEARTBEAT_STATE_FILE", str(Path.home() / "JarvisHeartbeatState.json"))
)

# --- Rails (Tier 6) -------------------------------------------------------

# A plain, appended-to log of what Jarvis did and why: every tool call,
# every confirmation asked (and the answer), every heartbeat notice, and
# per-turn token usage. When something surprises you, this is how you
# find out what happened.
AUDIT_LOG_FILE = Path(os.environ.get("JARVIS_AUDIT_LOG_FILE", str(Path.home() / "JarvisAuditLog.md")))

# Tool names that must stop and get your explicit yes before running -
# straight from the "never without asking" list: sending a message,
# spending money, deleting data, changing a setting. Add a tool name
# here (or via JARVIS_EXTRA_CONFIRM_TOOLS, comma-separated) as new
# tools are added - a config edit, never a code change.
_default_confirm_tools = {"forget_fact"}
_extra_confirm_tools = {
    name.strip()
    for name in os.environ.get("JARVIS_EXTRA_CONFIRM_TOOLS", "").split(",")
    if name.strip()
}
CONFIRMATION_REQUIRED_TOOLS = _default_confirm_tools | _extra_confirm_tools

# One obvious way to pause ALL heartbeat activity without tearing
# anything down: create this file (or run `python -m
# jarvis.heartbeat.pause`) and the heartbeat loop keeps running but
# skips every check until the file is removed (or you run `python -m
# jarvis.heartbeat.resume`). Your foreground conversation with Jarvis
# is unaffected either way.
KILL_SWITCH_FILE = Path(os.environ.get("JARVIS_KILL_SWITCH_FILE", str(Path.home() / "JARVIS_PAUSED")))
