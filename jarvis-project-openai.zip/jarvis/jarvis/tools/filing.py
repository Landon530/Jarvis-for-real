"""
Shared filing logic: every model Jarvis produces goes into one folder,
with a clear name, so nothing gets lost. This is the "auto-organize"
capability from the interview — not its own tool, a behavior every
model-producing tool wraps itself in.
"""

from __future__ import annotations

import datetime as _dt
from pathlib import Path

from jarvis.config import ensure_models_dir


def file_model(source_stem: str, tag: str, mesh) -> Path:
    """
    Export `mesh` into the managed models folder with a name that says
    what it is and when it was made, and return the path it was written
    to. Never overwrites an existing file — if a name collides, a
    timestamp makes it unique.
    """
    models_dir = ensure_models_dir()
    timestamp = _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    filename = f"{source_stem}_{tag}_{timestamp}.stl"
    out_path = models_dir / filename
    mesh.export(out_path)
    return out_path
