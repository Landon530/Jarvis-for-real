"""
The tool registry.

A tool is a named capability with a clear description and a typed input
schema. The model sees the whole registry every turn and decides when to
call one; the harness looks it up by name, runs it, and feeds the result
(or a plain-language error) back to the model.

Adding a new capability should always mean: write one self-contained
tool, register it here. Never edit the conversation loop to add a tool.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass


class ToolError(Exception):
    """Raised by a tool handler for an expected, explainable failure
    (bad input, file not found, etc). The message is shown to the model,
    not the raw traceback — the model can then explain it to the user or
    recover."""


@dataclass
class Tool:
    name: str
    description: str  # written for the model to read, not a compiler
    input_schema: dict  # JSON schema, per Anthropic's tool-use format
    handler: Callable[[dict], str]  # takes validated inputs, returns result text
    # Optional: given the tool's input, return a plain-language sentence
    # describing exactly what's about to happen. Used by the Tier 6
    # confirmation gate for tools listed in config.CONFIRMATION_REQUIRED_TOOLS.
    # If omitted, the gate falls back to a generic description.
    confirmation_prompt: Callable[[dict], str] | None = None


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        self._tools[tool.name] = tool

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def as_anthropic_tools(self) -> list[dict]:
        """The shape the SDK's `tools=` parameter expects."""
        return [
            {
                "name": tool.name,
                "description": tool.description,
                "input_schema": tool.input_schema,
            }
            for tool in self._tools.values()
        ]

    def run(self, name: str, tool_input: dict) -> tuple[str, bool]:
        """
        Run a registered tool by name. Never raises — a tool failure or
        an unknown tool name comes back as a plain-language string and
        an `is_error` flag, so the model can reason over it instead of
        the harness crashing.

        Returns (result_text, is_error).
        """
        tool = self._tools.get(name)
        if tool is None:
            return f"No such tool: '{name}'.", True

        try:
            return tool.handler(tool_input), False
        except ToolError as exc:
            return str(exc), True
        except Exception as exc:  # noqa: BLE001 - deliberate catch-all
            # An unexpected bug in a tool should still come back as text,
            # not take down the whole conversation loop.
            return f"Unexpected error in tool '{name}': {exc}", True
