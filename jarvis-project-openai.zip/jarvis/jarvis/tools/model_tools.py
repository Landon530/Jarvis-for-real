"""
Jarvis's first two real tools:

1. analyze_stl  — read-only. Loads a mesh, reports dimensions and any
   printability problems in plain language. Safe to run on its own.
2. improve_stl  — applies one or more explicit, named fixes and writes
   the RESULT as a new file via `filing.file_model`. Never touches or
   overwrites the original, so it doesn't need to sit behind the
   consequential-action confirmation gate (nothing is deleted or lost —
   quite the opposite of the point of this tool).

Both tools take typed, explicit inputs — no freeform blobs the model
has to be trusted to format correctly.
"""

from __future__ import annotations

from pathlib import Path

import trimesh

from jarvis.tools.filing import file_model
from jarvis.tools.registry import Tool, ToolError


def _load_mesh(file_path: str) -> trimesh.Trimesh:
    path = Path(file_path).expanduser()
    if not path.exists():
        raise ToolError(f"No file found at '{file_path}'.")
    if path.suffix.lower() != ".stl":
        raise ToolError(f"'{file_path}' doesn't look like an STL file.")
    try:
        mesh = trimesh.load(path, force="mesh")
    except Exception as exc:  # noqa: BLE001
        raise ToolError(f"Couldn't read '{file_path}' as a mesh: {exc}") from exc
    if not isinstance(mesh, trimesh.Trimesh):
        raise ToolError(f"'{file_path}' didn't load as a single mesh.")
    return mesh


# ---------------------------------------------------------------------------
# analyze_stl
# ---------------------------------------------------------------------------

def _analyze_stl(tool_input: dict) -> str:
    file_path = tool_input["file_path"]
    mesh = _load_mesh(file_path)

    extents = mesh.bounding_box.extents  # (x, y, z) in the file's native units
    issues: list[str] = []

    if not mesh.is_watertight:
        issues.append(
            "The mesh is NOT watertight (has holes) — most slicers will "
            "either reject this or silently produce a broken print."
        )

    degenerate = mesh.faces.shape[0] - mesh.nondegenerate_faces().sum()
    if degenerate > 0:
        issues.append(f"{degenerate} degenerate (zero-area) faces found.")

    if mesh.euler_number != 2:
        issues.append(
            f"Euler number is {mesh.euler_number}, not 2 — the mesh likely "
            f"has topology problems (holes, non-manifold edges, or "
            f"disconnected pieces)."
        )

    min_extent = min(extents)
    if min_extent < 1.0:
        issues.append(
            f"Smallest bounding-box dimension is {min_extent:.2f} units — "
            f"if this is millimeters, some feature may be too thin to "
            f"print reliably."
        )

    body_count = mesh.body_count
    if body_count > 1:
        issues.append(
            f"Mesh contains {body_count} disconnected pieces — confirm "
            f"that's intentional and not a modeling error."
        )

    report_lines = [
        f"File: {file_path}",
        f"Dimensions (bounding box): {extents[0]:.2f} x {extents[1]:.2f} x {extents[2]:.2f} (native units, likely mm)",
        f"Volume: {mesh.volume:.2f} cubic units",
        f"Watertight: {mesh.is_watertight}",
        f"Disconnected pieces: {body_count}",
    ]
    if issues:
        report_lines.append("Issues found:")
        report_lines.extend(f"- {issue}" for issue in issues)
    else:
        report_lines.append("No issues detected — looks printable as-is.")

    return "\n".join(report_lines)


analyze_stl = Tool(
    name="analyze_stl",
    description=(
        "Load an STL file and report its dimensions, volume, and any "
        "printability problems (non-watertight geometry, degenerate "
        "faces, disconnected pieces, suspiciously thin features). "
        "Read-only — does not modify the file. Use this whenever the "
        "person wants feedback on a 3D model they've designed."
    ),
    input_schema={
        "type": "object",
        "properties": {
            "file_path": {
                "type": "string",
                "description": "Path to the .stl file to analyze.",
            }
        },
        "required": ["file_path"],
    },
    handler=_analyze_stl,
)


# ---------------------------------------------------------------------------
# improve_stl
# ---------------------------------------------------------------------------

def _improve_stl(tool_input: dict) -> str:
    file_path = tool_input["file_path"]
    fix_normals = tool_input.get("fix_normals", False)
    fill_holes = tool_input.get("fill_holes", False)
    smooth = tool_input.get("smooth", False)
    scale_factor = tool_input.get("scale_factor")
    mirror_axis = tool_input.get("mirror_axis")

    requested = [fix_normals, fill_holes, smooth, scale_factor, mirror_axis]
    if not any(requested):
        raise ToolError(
            "No operation specified — set at least one of fix_normals, "
            "fill_holes, smooth, scale_factor, or mirror_axis."
        )

    mesh = _load_mesh(file_path)
    applied: list[str] = []

    if fix_normals:
        trimesh.repair.fix_normals(mesh)
        applied.append("fixed face normals")

    if fill_holes:
        filled = trimesh.repair.fill_holes(mesh)
        applied.append("filled holes" if filled else "attempted to fill holes (some may remain)")

    if smooth:
        trimesh.smoothing.filter_laplacian(mesh, iterations=10)
        applied.append("smoothed surface (laplacian, 10 iterations)")

    if scale_factor is not None:
        if scale_factor <= 0:
            raise ToolError("scale_factor must be a positive number.")
        mesh.apply_scale(scale_factor)
        applied.append(f"scaled by {scale_factor}x")

    if mirror_axis is not None:
        if mirror_axis not in ("x", "y", "z"):
            raise ToolError("mirror_axis must be 'x', 'y', or 'z'.")
        transform = trimesh.transformations.scale_matrix(
            -1, origin=[0, 0, 0], direction={"x": [1, 0, 0], "y": [0, 1, 0], "z": [0, 0, 1]}[mirror_axis]
        )
        mesh.apply_transform(transform)
        applied.append(f"mirrored across {mirror_axis}-axis")

    source_stem = Path(file_path).stem
    tag = "-".join(a.split()[0] for a in applied)  # short tag for the filename
    out_path = file_model(source_stem, tag, mesh)

    return (
        f"Applied: {', '.join(applied)}.\n"
        f"Saved improved version to: {out_path}\n"
        f"Original file was left untouched."
    )


improve_stl = Tool(
    name="improve_stl",
    description=(
        "Apply one or more explicit fixes to an STL file (fix inverted "
        "normals, fill holes, smooth the surface, scale, or mirror), "
        "then save the result as a NEW file — the original is never "
        "modified or deleted. The new file is automatically filed into "
        "the managed models folder. Use this after analyze_stl has "
        "identified a specific, named problem the person wants fixed, "
        "or when they explicitly ask for one of these operations."
    ),
    input_schema={
        "type": "object",
        "properties": {
            "file_path": {
                "type": "string",
                "description": "Path to the source .stl file.",
            },
            "fix_normals": {
                "type": "boolean",
                "description": "Recalculate face normals so shading/slicing is correct.",
            },
            "fill_holes": {
                "type": "boolean",
                "description": "Attempt to fill holes to make the mesh watertight.",
            },
            "smooth": {
                "type": "boolean",
                "description": "Apply light laplacian smoothing to the surface.",
            },
            "scale_factor": {
                "type": "number",
                "description": "Multiply the model's size by this factor (e.g. 1.5 for 50% bigger).",
            },
            "mirror_axis": {
                "type": "string",
                "enum": ["x", "y", "z"],
                "description": "Mirror the model across this axis.",
            },
        },
        "required": ["file_path"],
    },
    handler=_improve_stl,
)
