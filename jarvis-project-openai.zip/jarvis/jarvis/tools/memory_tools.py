"""
Tools that let Jarvis manage its own durable memory (Tier 4).

Kept deliberately narrow: one clear statement per fact, no freeform
"update everything you know" tool. Small, legible entries are what
keep memory.py's file easy for a person to review and correct by hand.
"""

from __future__ import annotations

from jarvis import memory_store
from jarvis.tools.registry import Tool, ToolError


def _remember(tool_input: dict) -> str:
    fact = tool_input.get("fact", "").strip()
    if not fact:
        raise ToolError("No fact text given to remember_fact.")
    memory_store.add_fact(fact)
    return f"Remembered: {fact}"


remember_fact = Tool(
    name="remember_fact",
    description=(
        "Store a durable fact about the person or their world that "
        "should be remembered in future sessions - a preference, an "
        "identity detail, a standing decision. Write it as ONE clear, "
        "self-contained statement (e.g. 'Prefers metric units for print "
        "dimensions'). Don't use this for details relevant only to the "
        "current conversation - only things worth knowing next time too."
    ),
    input_schema={
        "type": "object",
        "properties": {
            "fact": {
                "type": "string",
                "description": "The fact to remember, as one plain statement.",
            }
        },
        "required": ["fact"],
    },
    handler=_remember,
)


def _forget(tool_input: dict) -> str:
    text = tool_input.get("fact", "").strip()
    if not text:
        raise ToolError("No text given to forget_fact.")
    removed = memory_store.remove_fact(text)
    if not removed:
        return f"No stored fact matched '{text}' — nothing removed."
    return f"Removed: {'; '.join(removed)}"


def _forget_confirmation(tool_input: dict) -> str:
    text = tool_input.get("fact", "")
    return (
        f"Delete any stored fact matching '{text}' from memory? "
        f"This removes it from JarvisMemory.md — you can always tell me "
        f"to remember it again later, but it won't carry forward on its own."
    )


forget_fact = Tool(
    name="forget_fact",
    description=(
        "Delete a previously stored fact that's now wrong or no longer "
        "applies. Matches against stored facts by substring - be "
        "specific enough that it only matches the one you mean. Use "
        "this when the person corrects or retracts something you knew."
    ),
    input_schema={
        "type": "object",
        "properties": {
            "fact": {
                "type": "string",
                "description": "Text that identifies the stored fact to remove.",
            }
        },
        "required": ["fact"],
    },
    handler=_forget,
    confirmation_prompt=_forget_confirmation,
)


def _update(tool_input: dict) -> str:
    old = tool_input.get("old_fact", "").strip()
    new = tool_input.get("new_fact", "").strip()
    if not old or not new:
        raise ToolError("Both old_fact and new_fact are required for update_fact.")
    updated = memory_store.update_fact(old, new)
    if not updated:
        return f"No stored fact matched '{old}' — nothing updated."
    return f"Updated fact to: {new}"


update_fact = Tool(
    name="update_fact",
    description=(
        "Replace an outdated stored fact with a corrected one, in a "
        "single step (equivalent to forget_fact + remember_fact). Use "
        "this when a known fact has simply changed, e.g. a preference "
        "shifted, rather than being wrong from the start."
    ),
    input_schema={
        "type": "object",
        "properties": {
            "old_fact": {
                "type": "string",
                "description": "Text that identifies the stored fact to replace.",
            },
            "new_fact": {
                "type": "string",
                "description": "The corrected fact, as one plain statement.",
            },
        },
        "required": ["old_fact", "new_fact"],
    },
    handler=_update,
)
